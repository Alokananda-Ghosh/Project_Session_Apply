package com.cg.Dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.cg.bean.Product;
import com.cg.util.CUtil;

public class IDaoImpl implements IDao {

	@Override
	public int setProduct(int pid,Product p) 
	{
		// TODO Auto-generated method stub
	
		CUtil.sethm(pid, p);
		return p.getProductid();
		
	}

	@Override
	public Product getProduct(int pid) {
		// TODO Auto-generated method stub
		Product p=null;
		Set<Integer> set= CUtil.gethm().keySet();
		Iterator<Integer> itr=set.iterator();
		while(itr.hasNext())
		{
			int id=itr.next();
			if(id==pid) {
				 p=CUtil.gethm().get(pid);
				
			}
		}
			System.out.println(p);
		return p;
	}

	@Override
	public HashMap<Integer, Product> getAll() {
		// TODO Auto-generated method stub
		return CUtil.gethm();
	}

    
}
