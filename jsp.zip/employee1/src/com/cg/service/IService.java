package com.cg.service;

import java.util.HashMap;

import com.cg.bean.Product;

public interface IService 
{
public int setProduct(int pid,Product p);
public Product getProduct(int pid);
public HashMap<Integer,Product> getAll();
}
