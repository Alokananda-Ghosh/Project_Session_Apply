package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.Product;
import com.cg.service.IService;
import com.cg.service.IServiceImpl;
import com.cg.util.CUtil;

/**
 * Servlet implementation class productservlet
 */
@WebServlet({"/productservlet","/add","/home","/get","/show","/showall","/deleteProduct"})
public class productservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public productservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		HttpSession session=null;
		PrintWriter out=response.getWriter();
		Product p=new Product();
		IService iss=new IServiceImpl();
		String s=request.getServletPath();
		if(s.equals("/add"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("productdetails.jsp");
			rd.include(request,response);
		}
		if(s.equals("/productservlet"))
		{
		
	
		int id1=Integer.parseInt(request.getParameter("pid"));
		p.setProductid(id1);
		String category=request.getParameter("pcategory");
		p.setProductcategory(category);
		String name=request.getParameter("pname");
		p.setProductname(name);
		int productprice=Integer.parseInt(request.getParameter("pprice"));
		p.setProductprice(productprice);
		int productqty=Integer.parseInt(request.getParameter("pqty"));
		p.setProductquantity(productqty);
		
		request.setAttribute("pid", iss.setProduct(id1, p));
		RequestDispatcher rd=request.getRequestDispatcher("success.jsp");
		rd.forward(request,response);
		}
		if(s.equals("/home"))
		{   
			session=request.getSession(true);
			out.println(session.getId());
			RequestDispatcher rd1=request.getRequestDispatcher("Index.jsp");
			rd1.include(request,response);
		}
		if(s.equals("/get"))
				{
			RequestDispatcher rd1=request.getRequestDispatcher("showDetails.jsp");
			rd1.include(request,response);
				}
		if(s.equals("/show"))
		{
			
			int id1=Integer.parseInt(request.getParameter("pid"));
		    Product p1=iss.getProduct(id1);
		    request.setAttribute("productid",p1.getProductid());
		    request.setAttribute("productcat",p1.getProductcategory());
		    request.setAttribute("productcname",p1.getProductname());
		    request.setAttribute("productprice",p1.getProductprice());
		    request.setAttribute("productquantity",p1.getProductquantity());
		    
			//out.println(p1);
			RequestDispatcher rd1=request.getRequestDispatcher("showDetails.jsp");

			rd1.include(request,response);
		}
		if(s.equals("/showall"))
			{
			  HashMap<Integer,Product> products=iss.getAll();
			  session=request.getSession(false);
			  try
			  {
				  session.setAttribute("products", products);
			  }
			  catch(Exception e)
			  {
				  System.out.println("session not present");
			  }
			  out.println(session.getId());
			
				RequestDispatcher rd1=request.getRequestDispatcher("showall.jsp");
               rd1.include(request,response);
			}
		if(s.equals("/deleteProduct"))
		{
			 session=request.getSession(false);
		
		  HashMap<Integer,Product> products= (HashMap<Integer,Product>)session.getAttribute("products");
		  products.remove(Integer.parseInt(request.getParameter("id")));
			RequestDispatcher rd1=request.getRequestDispatcher("showall.jsp");
            rd1.include(request,response);
		}
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
