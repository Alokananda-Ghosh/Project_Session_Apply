package com.cg.tms.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketCategory;
import com.cg.tms.util.Util;

public class TicketDAOImpl implements TicketDAO {
	private static Map<String,String> ticketCategory=new HashMap<String,String>();
	@Override
	public boolean raiseNewTicket(String ticketBean) {
		// TODO Auto-generated method stub
		if(ticketBean.equals(TicketCategory.getTicketCategoryId())){
		return true;
	}
	else {
		return false;
	}
}
	@Override
	public List<TicketCategory> listTicketCategory() {
		// TODO Auto-generated method stub
	//	HashMap<String,String> p=(HashMap<String, String>) Util.getTicketCategoryEntries().values().iterator();
		return (List<TicketCategory>)Util.getTicketCategoryEntries();
		
	}
}
