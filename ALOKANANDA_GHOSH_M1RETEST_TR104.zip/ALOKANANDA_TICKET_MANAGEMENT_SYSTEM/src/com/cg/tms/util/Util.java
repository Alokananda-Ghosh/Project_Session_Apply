package com.cg.tms.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.tms.dto.TicketBean;

public class Util {
private static Map<String,String> ticketCategory=new HashMap<String,String>();
public static Map<String,String> getTicketCategoryEntries(){
	ticketCategory.put("tc0001","software installation");
	ticketCategory.put("tc0002","mailbox creation");
	ticketCategory.put("tc0003","mailbox issues");
	return ticketCategory;
	
	
}
private static Map<String,String> TicketLog=new HashMap<String,String>();
public static String setDetails(String id,String ticketBean) {
	return TicketLog.put(id,ticketBean);
}
}
