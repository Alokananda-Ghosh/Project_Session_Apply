package com.cg.tms.dto;

public class TicketBean {//applying getter-setter,to-string and constructor
private String ticketNo;
private String ticketCategoryId;
private String ticketDescription;
private String ticketPriority;
private String ticketStatus;
public TicketBean(String tn,String tcd,String td,String tp,String ts) {
	this.ticketNo=tn;
	this.ticketCategoryId=tcd;
	this.ticketDescription=td;
	this.ticketPriority=tp;
	this.ticketStatus=ts;
	
}
public String getTicketNo() {
	return ticketNo;
}
public void setTicketNo(String ticketNo) {
	this.ticketNo = ticketNo;
}
public String getTicketCategoryId() {
	return ticketCategoryId;
}
public void setTicketCategoryId(String ticketCategoryId) {
	this.ticketCategoryId = ticketCategoryId;
}
public String getTicketDescription() {
	return ticketDescription;
}
public void setTicketDescription(String ticketDescription) {
	this.ticketDescription = ticketDescription;
}
public String getTicketPriority() {
	return ticketPriority;
}
public void setTicketPriority(String ticketPriority) {
	this.ticketPriority = ticketPriority;
}
@Override
public String toString() {
	return "TicketBean [ticketNo=" + ticketNo + ", ticketCategoryId=" + ticketCategoryId + ", ticketDescription="
			+ ticketDescription + ", ticketPriority=" + ticketPriority + ", ticketStatus=" + ticketStatus
			+ ", itimdComments=" + itimdComments + "]";
}
public String getTicketStatus() {
	return ticketStatus;
}
public void setTicketStatus(String ticketStatus) {
	this.ticketStatus = ticketStatus;
}
public String getItimdComments() {
	return itimdComments;
}
public void setItimdComments(String itimdComments) {
	this.itimdComments = itimdComments;
}
private String itimdComments;
}
