package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketServiceImpl implements TicketService {
TicketDAO tcd=new TicketDAOImpl();
@Override
	public boolean raiseNewTicket(String ticketBean) {
		return tcd.raiseNewTicket(ticketBean);
		
	}
@Override
	public List<TicketCategory> listTicketCategory() {
	// TODO Auto-generated method stub
	return tcd.listTicketCategory();
}

	
	
}
