package com.cg.tms.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {
	public static void main(String args[]) throws IOException {
		TicketService s = new TicketServiceImpl();
		while (true) {

			System.out.println("Select Ticket Category from below List:");
			System.out.println("1.Raise a Ticket\n2.Exit from the system");
			Scanner sc = new Scanner(System.in);
			int a = sc.nextInt();
			switch (a) {
			case 1:

				TicketBean tb = new TicketBean(null, null, null, null, null);
				Random ob = new Random();
				int alo = ob.nextInt(1000);
				tb.setTicketNo(Integer.toString(alo));

				String catId;
				do {
					System.out.println(
							"Select Ticket Category from below list:\n1:Software Installation\n2:Mailbox creation\n3:network issues\nEnter option:");

					catId = sc.next();
				} while (!(catId.equals("1") || catId.equals("2") || catId.equals("3")));// validation for choosing
																							// option
				tb.setTicketCategoryId(catId);
				System.out.println("Enter Description related to issue:");
				String m;
				String regex;
				do {
					System.out.println("Enter ticket Description:");
					m = sc.next();
					regex = "[a-zA-Z0-9]+";
				} while (!m.matches(regex));
				tb.setTicketDescription(m);
				String x;
				do {
					System.out.println("Enter ticket priority");
					x = sc.next();
				} while (!(x.equals("high") || x.equals("medium") || x.equals("low")));// validation for choosing
																						// priority
				tb.setTicketPriority(x);
				tb.setTicketStatus("New");
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				System.out.println("Enter comments");

				String com = br.readLine();

				tb.setItimdComments(com);
				System.out.println(tb);

				System.out.println(
						"Ticket Number " + alo + " logged successfully at " + LocalDate.now() + "" + LocalTime.now());// show
																														// the
																														// current
																														// time
																														// and
																														// date
																														// when
																														// the
																														// operation
																														// executed
				break;
			case 2:
				System.out.println("Terminated");
				System.exit(0);
				break;
			default:
				System.out.println("Wrong choice entered");
			}

		}
	}
}